/**********************************************************************

	Implementacja pewnego podzbioru jezyka Logo (sterowanie Zolwiem)
	M.Gagolewski@mini.pw.edu.pl

	Poprawki:
	Michal Debski

 **********************************************************************/

#include "Logo.h"
#define _CRT_SECURE_NO_WARNINGS
#include <cmath>
#include <cassert>
#include <fstream>
#include <cstring>

#define M_PI                3.14159265358979323846


Rysunek::Rysunek(const char* nazwaPliku, int szerokosc, int wysokosc, kolor tlo)
	: cx(szerokosc), cy(wysokosc)
{
	this->nazwaPliku = new char[strlen(nazwaPliku)+1];
	strcpy(this->nazwaPliku, nazwaPliku);

	this->bmp = new RGBTRIPLE[cx*cy];

	for (int i=0; i<cx*cy; ++i) bmp[i] = tlo;
}


Rysunek::~Rysunek()
{
	if (bmp) delete [] bmp;
	if (nazwaPliku) delete [] nazwaPliku;
}


void Rysunek::punkt(int x, int y, kolor k)
{
	if (x >= 0 && x < cx && y >= 0 && y < cy)
		bmp[y*cx+x] = k;
}


void Rysunek::odcinek(int x1, int y1, int x2, int y2, kolor k)
{
	// Algorytm DDA
	double dy = y2-(float)y1;
	double dx = x2-(float)x1;
	double m = dy/dx;

	if (fabs(m) <= 1.0)
	{
		if (x2 < x1)
		{
			int xx = x1; x1 = x2; x2 = xx;
			int yy = y1; y1 = y2; y2 = yy;
		}

		double y = (double)y1;
		for (int x=x1; x<=x2; x++)
		{
			punkt(x, int(y+0.5), k);
			y += m;
		}
	}
	else
	{
		if (y2 < y1)
		{
			int xx = x1; x1 = x2; x2 = xx;
			int yy = y1; y1 = y2; y2 = yy;
		}

		m = 1.0/m;
		double x = (double)x1;

		for (int y=y1; y<=y2; y++)
		{
			punkt(int(x+0.5), y, k);
			x += m;
		}
	}
}



void Rysunek::zapisz()
{
	assert(sizeof(BITMAPINFOHEADER)==40);
	assert(sizeof(BITMAPFILEHEADER)==14);
	assert(sizeof(WORD)==2);
	assert(sizeof(DWORD)==4);
	assert(sizeof(LONG)==4);
	assert(sizeof(BYTE)==1);
	assert(sizeof(RGBTRIPLE)==3);


	std::ofstream plik;
	plik.open(nazwaPliku, std::ios_base::out|std::ios_base::binary|std::ios_base::trunc);



	BITMAPFILEHEADER head;
	head.bfType = 0x4D42;
	head.bfSize = sizeof(BITMAPFILEHEADER)+sizeof(BITMAPINFOHEADER)+sizeof(RGBTRIPLE)*cx*cy;
	head.bfReserved1 = 0;
	head.bfReserved2 = 0;
	head.bOffBits = sizeof(BITMAPFILEHEADER)+sizeof(BITMAPINFOHEADER);

	plik.write((const char*)&head, sizeof(head));



	BITMAPINFOHEADER info;
	info.biSize = sizeof(BITMAPINFOHEADER);
	info.biWidth = cx;
	info.biHeight = cy;
	info.biPlanes = 1;
	info.biBitCount = 24;
	info.biCompression = 0;
	info.biSizeImage = sizeof(RGBTRIPLE)*cx*cy;
	info.biXPelsPerMeter = 0;
	info.biYPelsPerMeter = 0;
	info.biClrUsed = 0;
	info.biClrImportant = 0;

	plik.write((const char*)&info, sizeof(info));



	plik.write((const char*)bmp,   sizeof(RGBTRIPLE)*cx*cy);


	assert(!plik.fail());

	plik.close();
}



Logo::Logo(Rysunek* _rys, kolor _pisak)
{
	this->rys = _rys;
	this->pisak = _pisak;
	this->pisanie = true;

	x = rys->szerokosc()*0.5;
	y = rys->wysokosc()*0.5;
	kat = 0.0;
}


Logo::~Logo()
{
	rys->zapisz();
}


void Logo::naprzod(double ile)
{
	double x0 = x;
	double y0 = y;
	x = x0 + sin(kat*M_PI/180.0)*ile;
	y = y0 + cos(kat*M_PI/180.0)*ile;

// 	std::cout << x0 << " " << y0 << "\n";
// 	std::cout << x << " " << y << "\n";

	if (pisanie)
		rys->odcinek((int)(x0+0.5), (int)(y0+0.5), (int)(x+0.5), (int)(y+0.5), pisak);
}


void Logo::cofnij(double ile)
{
	naprzod(-ile);
}


void Logo::prawo(double obrot)
{
	kat += obrot;

	if (kat < 0.0) kat += 360.0;
	else if (kat >= 360.0) kat -= 360.0;

// 	if (kat < 0.0) kat = 2.0*M_PI+kat;
// 	else if (kat > 2.0*M_PI) kat = kat-2.0*M_PI;
}


void Logo::lewo(double obrot)
{
	prawo(-obrot);
}



// --------------------------------------------------------------

Logo* __logo = NULL;

void inicjuj(const char* nazwaPliku, int szerokosc, int wysokosc)
{
	__logo = new Logo(new Rysunek(nazwaPliku, szerokosc, wysokosc));
}

void zakoncz()
{
	assert(__logo);
	delete __logo;
	__logo = NULL;
}

void naprzod(double ile)
{
	assert(__logo);
	__logo->naprzod(ile);
}

void cofnij(double ile)
{
	assert(__logo);
	__logo->cofnij(ile);
}


void prawo(double kat)
{
	assert(__logo);
	__logo->prawo(kat);
}


void lewo(double kat)
{
	assert(__logo);
	__logo->lewo(kat);
}


void podnies()
{
	assert(__logo);
	__logo->podnies();
}

void opusc()
{
	assert(__logo);
	__logo->opusc();
}


void ustawKolor(kolor pisak)
{
	assert(__logo);
	__logo->ustawKolor(pisak);
}

