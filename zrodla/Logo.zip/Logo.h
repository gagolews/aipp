/**********************************************************************

	Implementacja pewnego podzbioru jezyka Logo (sterowanie Zolwiem)
	M.Gagolewski@mini.pw.edu.pl

	Poprawki:
	Michal Debski

 **********************************************************************/


#ifndef __Logo_h
#define __Logo_h



/**********************************************************************

	Klasa do tworzenia plikow BMP
	M.Gagolewski@mini.pw.edu.pl

 **********************************************************************/



#include <iostream>
#include "pstdint.h"


#define WORD uint16_t
#define DWORD uint32_t
#define LONG int32_t
#define BYTE uint8_t


#pragma pack(push)
#pragma pack(1)
struct RGBTRIPLE
{
	RGBTRIPLE(BYTE R, BYTE G, BYTE B) {r=R; g=G; b=B;}
	RGBTRIPLE() { }
	BYTE b, g, r;
};

struct BITMAPFILEHEADER
{
	WORD bfType; //specifies the file type
	DWORD bfSize; //specifies the size in bytes of the bitmap file
	WORD bfReserved1; //reserved; must be 0
	WORD bfReserved2; //reserved; must be 0
	DWORD bOffBits; //species the offset in bytes from the bitmapfileheader to the bitmap bits
};

struct BITMAPINFOHEADER
{
	LONG biSize; //specifies the number of bytes required by the struct
	LONG biWidth; //specifies width in pixels
	LONG biHeight; //species height in pixels
	WORD biPlanes; //specifies the number of color planes, must be 1
	WORD biBitCount; //specifies the number of bit per pixel
	DWORD biCompression;//spcifies the type of compression
	DWORD biSizeImage; //size of image in bytes
	LONG biXPelsPerMeter; //number of pixels per meter in x axis
	LONG biYPelsPerMeter; //number of pixels per meter in y axis
	DWORD biClrUsed; //number of colors used by th ebitmap
	DWORD biClrImportant; //number of colors that are important
};
#pragma pack(pop)



typedef struct RGBTRIPLE kolor;

const kolor kCzarny    = kolor(0x00, 0x00, 0x00);
const kolor kBialy     = kolor(0xFF, 0xFF, 0xFF);
const kolor kCzerwony  = kolor(0xFF, 0x00, 0x00);
const kolor kZielony   = kolor(0x00, 0xFF, 0x00);
const kolor kNiebieski = kolor(0x00, 0x00, 0xFF);
const kolor kZolty     = kolor(0xFF, 0xFF, 0x00);
const kolor kCyjan     = kolor(0x00, 0xFF, 0xFF);
const kolor kFuksja    = kolor(0xFF, 0x00, 0xFF);
const kolor kSzary1    = kolor(0x33, 0x33, 0x33);
const kolor kSzary2    = kolor(0x77, 0x77, 0x77);
const kolor kSzary3    = kolor(0xBB, 0xBB, 0xBB);


class Rysunek
{
	public:

		Rysunek(const char* nazwaPliku, int szerokosc, int wysokosc, kolor tlo=kBialy);
		~Rysunek();

		void punkt(int x, int y, kolor k=kCzarny);
		void odcinek(int x0, int y0, int x1, int y1, kolor k);

		void zapisz();

		int wysokosc() { return cy; }
		int szerokosc() { return cx; }


	protected:

		const int cx, cy;


	private:

		RGBTRIPLE* bmp;
		char* nazwaPliku;
};


/* ------------------------------------------------------------------ */

class Logo
{
	public:

		Logo(Rysunek* rys, kolor pisak=kCzarny);
		~Logo();


		void naprzod(double ile);
		void cofnij(double ile);

		void prawo(double kat);
		void lewo(double kat);

		void podnies() { pisanie=false; }
		void opusc()   { pisanie=true;  }

		void ustawKolor(kolor _pisak) { pisak = _pisak; }


	private:

		double x; //< pozycja x zolwia
		double y; //< pozycja y zolwia
		double kat; //< kat zolwia w stopniach
		bool pisanie; //< tryb pisania wlaczony/wylaczony

		kolor pisak; //< kolor pisaka
		kolor tlo;   //< kolor tla

		Rysunek* rys;
};



/* ------------------------------------------------------------------ */

// Interfejs "funkcyjny"


extern Logo* __logo;

void inicjuj(const char* nazwaPliku, int szerokosc, int wysokosc);
void zakoncz();

void naprzod(double ile);
void cofnij(double ile);

void prawo(double kat);
void lewo(double kat);

void podnies();
void opusc();

void ustawKolor(kolor pisak);

#endif
